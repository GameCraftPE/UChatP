# UChatP
Ultimate chat protect plugin

# Features:
* chat cooldown
* block bad words 
* block adverting
